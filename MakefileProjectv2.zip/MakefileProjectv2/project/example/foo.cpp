
int foo(int i)
{
	return i + 1;
}

