int foo(int i);
