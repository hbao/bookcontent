
#include "stringhelper.h"

std::string 
StringHelperFun1(const std::string& str)
{
	return str + "--";
}

