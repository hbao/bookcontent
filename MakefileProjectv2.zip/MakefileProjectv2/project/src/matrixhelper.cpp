
#include "stringhelper.h"

std::string 
StringHelperFun2(const std::string& str)
{
	return str + "++";
}

