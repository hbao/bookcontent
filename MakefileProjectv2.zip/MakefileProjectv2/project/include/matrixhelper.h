
#include <string>

std::string StringHelperFun2(const std::string& str);

