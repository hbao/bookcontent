
#include <string>

std::string StringHelperFun1(const std::string& str);

